package myPackage;

public class Student {
	
	private int 	id;
	private String	firstName;
	private String	lastName;

	/**
	 * @param id
	 * @param firstName
	 * @param lastName
	 */
	public Student(int id, String firstName, String lastName) {
		super();
		this.id = id;
		this.firstName = firstName;
		this.lastName = lastName;
	}

	/**
	 * @return the firstName
	 */
	public String getFirstName() {
		return firstName;
	}

	/**
	 * @param firstName the firstName to set
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	/**
	 * @return the lastName
	 */
	public String getLastName() {
		return lastName;
	}

	/**
	 * @param lastName the lastName to set
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}
	
	// On crée pas la méthode setID car le id n'est pas modifiable	

	@Override
	public String toString() {
		return lastName +" "+ firstName + "("+id+")";
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Student student = new Student(1024, "Tahri", "Mohamed");
		
		System.out.println(student);
	}
}
package myPackage;

import java.util.ArrayList;
import java.util.List;

public class Wagon {

	private int numeroWagon;
	private List<Siege> sieges ;
	
	
	
	/**
	 * @param numeroWagon
	 */
	public Wagon(int numeroWagon) {
		super();
		this.numeroWagon = numeroWagon;
		this.sieges = new ArrayList<>(10);
		for(int i = 0; i < 10; i++)
			sieges.add(new Siege(i));
	}
	
	/**
	 * @param numeroWagon
	 * @param nombreSieges
	 */
	public Wagon(int numeroWagon, int nombreSieges) {
		super();
		this.numeroWagon = numeroWagon;
		this.sieges = new ArrayList<>(nombreSieges);
		for(int i = 0; i < nombreSieges; i++)
			sieges.add(new Siege(i));
	}

	public boolean complet() {
		for(Siege siege:sieges)
			if(siege.libre())
				return false;
		return true;
	}
	
	public boolean reserverSiege(Client c) {
		if(complet())
			return false;
		for(Siege siege:sieges)
			if(siege.libre()) {
				siege.reserver(c);
				return true;
			}
		return false;
	}

	@Override
	public String toString() {
		return "Wagon [numeroWagon=" + numeroWagon + ", sieges=" + sieges + ", complet()=" + complet() + "]";
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Client c = new Client(0, "Boutajine");
		Wagon w = new Wagon(1, 5);
		
		//System.out.println(w);
		
		//for(int i=0; i < 5 ; i++) {
		w.reserverSiege(c);
		//}
		
		System.out.println(w);
	}

}

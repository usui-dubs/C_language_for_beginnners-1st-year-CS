package myPackage;

import java.util.ArrayList;
import java.util.List;

public class Promotion {

	
	private List<Student> studentList;
	
	public Promotion() {
		studentList = new ArrayList<>();
	}
	
	
	public int add(String firstName, String lastName) {
		
		int newid = newID();
		studentList.add(new Student(newid, firstName, lastName));
		return newid;
		
	}
	
	private int newID() {
		// TODO Auto-generated method stub
		return studentList.isEmpty() ? 0 : studentList.size();
	}


	public void printToConsole() {
		
		for(Student s : studentList)
			System.out.println(s);
		
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Promotion L2Section2 = new Promotion();
		
		L2Section2.add("Benaissa", "Noureddine");
		L2Section2.add("Boukedjar", "Abdelali");
		L2Section2.add("Merine", "Farouk");
		L2Section2.add("Tab", "Ismail");
		L2Section2.add("Hammel", "Belmahdi");
		
		L2Section2.printToConsole();
		
	}

}

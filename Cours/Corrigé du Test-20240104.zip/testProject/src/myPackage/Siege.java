package myPackage;

public class Siege {
	
	private int 	numero;
	

	private boolean accepte ; // true signifie libre false occupé
	private Client  client ;
	/**
	 * @param numero
	 */
	public Siege(int numero) {
		super();
		this.numero = numero;
		this.accepte = true;
		this.client = null;
	}
	
	public boolean libre() {
		return this.accepte;
	}
	
	public void reserver(Client c) {
		this.client = c;
		this.accepte = false;
	}
	
	@Override
	public String toString() {
		return "Siege [numero=" + numero + ", accepte=" + accepte + ", client=" + client + ", libre()=" + libre() + "]\n";
	}
}

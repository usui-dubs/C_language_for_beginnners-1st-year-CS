package myPackage;

public class Client {
	private int numeroClient;
	private String nom;
	/**
	 * @param numeroClient
	 * @param nom
	 */
	public Client(int numeroClient, String nom) {
		super();
		this.numeroClient = numeroClient;
		this.nom = nom;
	}
	/**
	 * @return the numeroClient
	 */
	public int getNumeroClient() {
		return numeroClient;
	}
	/**
	 * @param numeroClient the numeroClient to set
	 */
	public void setNumeroClient(int numeroClient) {
		this.numeroClient = numeroClient;
	}
	/**
	 * @return the nom
	 */
	public String getNom() {
		return nom;
	}
	/**
	 * @param nom the nom to set
	 */
	public void setNom(String nom) {
		this.nom = nom;
	}
	@Override
	public String toString() {
		return "Client [numeroClient=" + numeroClient + ", nom=" + nom + "]";
	}
}
